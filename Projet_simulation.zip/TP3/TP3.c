/* 
   A C-program for MT19937, with initialization improved 2002/1/26.
   Coded by Takuji Nishimura and Makoto Matsumoto.

   Before using, initialize the state by using init_genrand(seed)  
   or init_by_array(init_key, key_length).

   Copyright (C) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura,
   All rights reserved.                          

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

     1. Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.

     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.

     3. The names of its contributors may not be used to endorse or promote 
        products derived from this software without specific prior written 
        permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


   Any feedback is very welcome.
   http://www.math.sci.hiroshima-u.ac.jp/~m-mat/MT/emt.html
   email: m-mat @ math.sci.hiroshima-u.ac.jp (remove space)
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* Period parameters */  
#define N 624
#define M 397
#define MATRIX_A 0x9908b0dfUL   /* constant vector a */
#define UPPER_MASK 0x80000000UL /* most significant w-r bits */
#define LOWER_MASK 0x7fffffffUL /* least significant r bits */

static unsigned long mt[N]; /* the array for the state vector  */
static int mti=N+1; /* mti==N+1 means mt[N] is not initialized */

/* initializes mt[N] with a seed */
void init_genrand(unsigned long s)
{
    mt[0]= s & 0xffffffffUL;
    for (mti=1; mti<N; mti++) {
        mt[mti] = 
	    (1812433253UL * (mt[mti-1] ^ (mt[mti-1] >> 30)) + mti); 
        /* See Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier. */
        /* In the previous versions, MSBs of the seed affect   */
        /* only MSBs of the array mt[].                        */
        /* 2002/01/09 modified by Makoto Matsumoto             */
        mt[mti] &= 0xffffffffUL;
        /* for >32 bit machines */
    }
}

/* initialize by an array with array-length */
/* init_key is the array for initializing keys */
/* key_length is its length */
/* slight change for C++, 2004/2/26 */
void init_by_array(unsigned long init_key[], int key_length)
{
    int i, j, k;
    init_genrand(19650218UL);
    i=1; j=0;
    k = (N>key_length ? N : key_length);
    for (; k; k--) {
        mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1664525UL))
          + init_key[j] + j; /* non linear */
        mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
        i++; j++;
        if (i>=N) { mt[0] = mt[N-1]; i=1; }
        if (j>=key_length) j=0;
    }
    for (k=N-1; k; k--) {
        mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1566083941UL))
          - i; /* non linear */
        mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
        i++;
        if (i>=N) { mt[0] = mt[N-1]; i=1; }
    }

    mt[0] = 0x80000000UL; /* MSB is 1; assuring non-zero initial array */ 
}

/* generates a random number on [0,0xffffffff]-interval */
unsigned long genrand_int32(void)
{
    unsigned long y;
    static unsigned long mag01[2]={0x0UL, MATRIX_A};
    /* mag01[x] = x * MATRIX_A  for x=0,1 */

    if (mti >= N) { /* generate N words at one time */
        int kk;

        if (mti == N+1)   /* if init_genrand() has not been called, */
            init_genrand(5489UL); /* a default initial seed is used */

        for (kk=0;kk<N-M;kk++) {
            y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
            mt[kk] = mt[kk+M] ^ (y >> 1) ^ mag01[y & 0x1UL];
        }
        for (;kk<N-1;kk++) {
            y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
            mt[kk] = mt[kk+(M-N)] ^ (y >> 1) ^ mag01[y & 0x1UL];
        }
        y = (mt[N-1]&UPPER_MASK)|(mt[0]&LOWER_MASK);
        mt[N-1] = mt[M-1] ^ (y >> 1) ^ mag01[y & 0x1UL];

        mti = 0;
    }
  
    y = mt[mti++];

    /* Tempering */
    y ^= (y >> 11);
    y ^= (y << 7) & 0x9d2c5680UL;
    y ^= (y << 15) & 0xefc60000UL;
    y ^= (y >> 18);

    return y;
}

/* generates a random number on [0,0x7fffffff]-interval */
long genrand_int31(void)
{
    return (long)(genrand_int32()>>1);
}

/* generates a random number on [0,1]-real-interval */
double genrand_real1(void)
{
    return genrand_int32()*(1.0/4294967295.0); 
    /* divided by 2^32-1 */ 
}

/* generates a random number on [0,1)-real-interval */
double genrand_real2(void)
{
    return genrand_int32()*(1.0/4294967296.0); 
    /* divided by 2^32 */
}

/* generates a random number on (0,1)-real-interval */
double genrand_real3(void)
{
    return (((double)genrand_int32()) + 0.5)*(1.0/4294967296.0); 
    /* divided by 2^32 */
}

/* generates a random number on [0,1) with 53-bit resolution*/
double genrand_res53(void) 
{ 
    unsigned long a=genrand_int32()>>5, b=genrand_int32()>>6; 
    return(a*67108864.0+b)*(1.0/9007199254740992.0); 
} 
/* These real versions are due to Isaku Wada, 2002/01/09 added */


/**************************************************************/
/**************************************************************/
/**************************************************************/

double simPi (long inNbPoints);
void printResultSimPi(long inNbPoints);
double *getResultSimPiInTab(int nbExperience, long inNbPoints);
double *createTable(int taille);
void printExo2(int nbExperience, long inNbPoints);
double getAverage(double *tab, int taille);
double getEstimateVariance(double *tab, int taille);
double confidenceRadius(double confidenceLevel, int nbExperience, long nbInPoint);
double getQuantileValue(double confidenceLevel, int nbExperience);
double *getConfidenceInterval(double confidenceLevel, int nbExperience, long nbInpoint);
void printExo3(double confidenceLevel, int nbExperience, long nbInpoint);

/**************************************************************/
/********************* FONCTION PRINCIPALE ********************/
/**************************************************************/


int main(void)
{

    unsigned long init[4]={0x123, 0x234, 0x345, 0x456}, length=4;
    init_by_array(init, length);

//    printResultSimPi(1000000000);
//    printExo2(40,1000000000);
    printExo3(0.99,30,1000000000);


    return 0;
}


/**************************************************************/
/*************************** EXO 1 ****************************/
/**************************************************************/

double simPi (long inNbPoints){
/*
    Cette fonction vise à retrouver la valeur du nombre Pi
    en fonction de nombre de points qui est passé en paramètre
    Pour chercher Pi, on procède au calcul de la surface d'un disque
    de rayon 1. L'ensemble de tous les points compris dans le disque
    forme sa surface.
    Pour connaitre si un point est dans le disque, on calcule
    la norme du vecteur formé par le point à partir de l'origine O
    grâce à la formule de Pythagore (OA^2 = OX^2 + OY^2) avec A(X,Y)
*/
    double x,y,pi,norme;
    int compteurPtInDisk = 0;

    for(int i=0; i<inNbPoints; i++){
        x = genrand_real1();
        y = genrand_real1();

        //Pythagore
        norme = x*x + y*y;

        if(norme <= 1)
            compteurPtInDisk ++;
    }

    //Pi équivaut à la surface du quart du disque fois 4
    pi = ((double)compteurPtInDisk/(double)inNbPoints)*4.;

    return pi;
}


void printResultSimPi(long inNbPoints){
/*
    Fonction d'affichage du résultat de la fonction
    simPi
*/
    printf("Pi = %f\n\n", simPi(inNbPoints));
}


/**************************************************************/
/*************************** EXO 2 ****************************/
/**************************************************************/

double *createTable(int taille){
/*
    Fonction qui crée un tableau de double
*/
    double *table = malloc(taille*sizeof(double));

    if(table == NULL){
        printf("Tableau non cree!\n");
        return NULL;
    }

    return table;
}


double *getResultSimPiInTab(int nbExperience, long inNbPoints){
/*
    Cette fonction retourne un tableau de résultats de la simulation
    simPi selon le nombre d'expériences "nbExperience"
*/
    double *resultTab = createTable(nbExperience);

    double pi;
    for(int i=0; i<nbExperience; i++){

        pi = simPi(inNbPoints);
        resultTab[i] = pi;
    }

    return resultTab;
}


double getAverage(double *tab, int taille){
/*
    Fonction qui calcule la moyenne arithmétique des 
    résultats contenus dans le tableau
*/
    if(tab == NULL){
        printf("Le tableau dans getAvg est NULL\n");
        return -1;
    }

    //Moyenne arithmétique
    double avg;
    double cumulatePi = 0.0;

    for(int i=0; i<taille; i++){
        cumulatePi += tab[i];
    }

    avg = cumulatePi/(double)taille;

    return avg;
}


void printExo2(int nbExperience, long inNbPoints){
/*
    Fonction qui affiche les résultats dans le tableau
    de Pi avec des informations supplémentaires comme 
    la moyenne arithmétique, les erreurs absolue et relative
*/
    double cumulatePi = 0.0;
    double arithmeticAvg;
    double *tabPi = createTable(nbExperience);
    tabPi = getResultSimPiInTab(nbExperience,inNbPoints);

    printf("----------------------- EXO2 ----------------------\n");
    printf("\nVoici les informations du tableau \n");
    printf("Les valeurs de PI:\n");
    for(int i=0; i<nbExperience; i++){

        cumulatePi += tabPi[i];

        if(i%5 == 0)
            printf("\n"); 

        printf("%f  ",tabPi[i]);
    }

    printf("\n\n");

    arithmeticAvg = getAverage(tabPi,nbExperience);

    printf("Moyenne arithmetique = %f\n", arithmeticAvg);
    printf("Erreur absolue = %f\n", arithmeticAvg-M_PI);
    printf("Erreur relative = %f\n\n", arithmeticAvg/M_PI);

    free(tabPi);
}


/**************************************************************/
/*************************** EXO 3 ****************************/
/**************************************************************/

double getEstimateVariance(double *tab, int taille){
/*
    Cette fonction calcule l'estimation de la variance
    par rapport aux résultats stockés dans le tableau.
    Si S est la variance estimée, avg la moyenne arithmétique
    et Xi les valeurs du tableau, sa formule est la suivante
    S = somme((Xi - avg)^2)/taille-1

*/
    double estimVariance, avg;
    double sum = 0.0;

    avg = getAverage(tab,taille);
    
    for(int i=0; i<taille; i++){
        sum += (tab[i] - avg)*(tab[i] - avg);
    }

    estimVariance = sum/(double)taille;

    return estimVariance;
}

double getQuantileValue(double confidenceLevel, int nbExperience){
/*
    Cette fonction reprend une partie du tableau de quantile selon le niveau de
    confiance qu'on définit. Dans cette exercice on ne prend en compte que 3 niveaux 
    de confiance pour un nombre d'expériences égal à 30 et 40.
    Elle retournera la valeur du quantile correspondant.
*/
    //case1: 30 expériences|| case2: 40 expériences
    double confidence95[] = {2.042,2.021};
    double confidence98[] = {2.457,2.423};
    double confidence99[] = {2.750,2.704};
    double quantile = 0.0;

    if(confidenceLevel == 0.95){
        if(nbExperience == 30)
            quantile = confidence95[0];
        if(nbExperience == 40)
            quantile = confidence95[1];
    }

    else if(confidenceLevel == 0.98){
        if(nbExperience == 30)
            quantile = confidence98[0];
        if(nbExperience == 40)
            quantile = confidence98[1];
    }

    else if (confidenceLevel == 0.99){
        if(nbExperience == 30)
            quantile = confidence99[0];
        if(nbExperience == 40)
            quantile = confidence99[1];        
    }

    return quantile;    
}


double confidenceRadius(double confidenceLevel, int nbExperience, long nbInPoint){
/*
    Cette fonction calcule le rayon de confiance par rapport au résultat de la simulation
    obtenu. On définit le niveau de confiance qu'on veut [de 0 à 1] (confidenceLevel, par 
    exemple 0.99 pour dire 99%) selon le nombre d'expérience et le nombre de points générés.
    Voici la formule du rayon de confiance: R = t*(S/n)^1/2 avec 
                t: le quantile que l'on prend dans le tableau de référence de la "loi student"
                S: la variance estimée.
                n: nombre d'expériences
*/

    double estimateVariance;
    double *tabPi;
    double quantile;
    double radius = 50.0;   //rayon par défaut :P

    tabPi = getResultSimPiInTab(nbExperience, nbInPoint);
    estimateVariance = getEstimateVariance(tabPi, nbExperience);
    quantile = getQuantileValue(confidenceLevel,nbExperience);

    //Calcul du rayon
    radius = estimateVariance/(double)nbExperience;
    radius = sqrt(radius);
    radius = quantile*radius;

    return radius;
}


double *getConfidenceInterval(double confidenceLevel, int nbExperience, long nbInpoint){
/*
    Cette fonction retourne l'intervalle de confiance dans un tableau. C'est-à-dire, 
    [PIMoyen-Radius; PIMoyen+Radius]
*/
    double *tabPi = getResultSimPiInTab(nbExperience,nbInpoint);
    double averagePi = getAverage(tabPi,nbExperience);
    double radius = confidenceRadius(confidenceLevel,nbExperience,nbInpoint);
    double *confidenceInterval = createTable(2);

    confidenceInterval[0] = averagePi-radius;
    confidenceInterval[1] = averagePi+radius;

    return confidenceInterval;
}


void printExo3(double confidenceLevel, int nbExperience, long nbInpoint){
/*
    Cette fonction affiche toutes les informations concernant l'exo3, notamment
    le rayon de confiance ainsi que les intervalles de confiance
*/
    double radius = confidenceRadius(confidenceLevel,nbExperience,nbInpoint);
    double *interval = getConfidenceInterval(confidenceLevel,nbExperience,nbInpoint);

    printf("----------------------- EXO3 ----------------------\n\n");
    printf("Niveau de confiance = %.0f%% \n", confidenceLevel*100);
    printf("Rayon de confiance = %f\n", radius);
    printf("Intervalle de confiance: ");
    printf("[%f - %f]\n\n", interval[0],interval[1]);

    free(interval);
}
