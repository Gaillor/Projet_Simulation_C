#include <stdio.h>
#include <stdlib.h>


int generate1(int seed, int iteration);
int pileOuFace();
void pileOuFaceStat(int iteration);
int dice(int nbFaces);
void diceStat(int nbFaces, int iteration);
int intRand();
float floatRand(int modulo);


int INTRAND_SEED = 5;	// variable globale pour pouvoir la réutiliser puisque la fonction intRand() version1 ne prend
			// pas de paramètre pour imiter l'utilisation de la fonction rand()



/**************************** DEBUT PROGRAMME PRINCIPALE ************/

int main(void){
	
/********************** EXO1 ************************/
/*	
	printf("Essai avec différents SEED\n");
	printf("Avec une itérration égale à 30\n");
	printf("\n");

	generate1(4100, 50);
	printf("-----------\n");

	generate1(1324, 50);
	printf("-----------\n");

	generate1(1301, 50);
	printf("-----------\n");

	generate1(3141, 50);
	printf("-----------\n");
	
*/

/********************** EXO4 ************************/	
/*	pileOuFaceStat(10);
	printf("\n");
	pileOuFaceStat(100);
	printf("\n");
	pileOuFaceStat(1000);
	printf("\n");
	return 0;
*/
	
/********************** EXO5 ************************/	
/*
	diceStat(6,100);
	diceStat(10,100);

*/
/********************** EXO6 ************************/	
// intRand()
	for(int i=0; i<32; i++){
		int nbRand = intRand()%16;

		if(nbRand < 0)
			nbRand = nbRand + 16;

		if(i == 31)
			printf("%d\n", nbRand);
		else
			printf("%d,", nbRand);
	}

printf("\n");

/********************** EXO7 ************************/	
// floatRand()
	for(int i=0; i<32; i++){
		if(i == 31)
			printf("%4g\n", floatRand(16));
		else
			printf("%4g,", floatRand(16));

	}

}

/*********************** FIN PROGRAMME PRINCIPALE ***************/


/*********************** FONCTIONS ******************************/


/*
 
Exo3:	D'après le manuel "man 3 rand", la fonction rand n'est pas fiable
	pour une étude scientifique; 
 
*/



int generate1(int seed, int iteration){
/*
	Fonction qui génère et affiche des nombres en partant du germe N0
	Fonctionnement sur un nombre de 8 chiffres; prend le juste
	milieu en enlevant les 2 premiers et les 2 dernies chiffres.

	Exemple: 15302030 ---> N = 3020	

*/
	int N0, N;

	N0 = seed;
	printf("N0 = %d \n", N0);

	for(int i=1; i<iteration; i++){
		
		N = N0*N0;
		N = (N/100)%10000;
		printf("N%d = %d \n",i,N);

		N0 = N;

	}

	return 0;
}


int pileOuFace(){
/*
	Fonction qui simule le jeu de la pile ou face, 0 pour la pile et
	1 pour la face.

*/
	
	int value;

	value = rand()%2;	// Prend le nombre entre [0,1]


	return value;
}

void pileOuFaceStat(int iteration){
/*
	Fonction qui teste l'equidistribution du jeu de la pile ou face
	en comparant le nombre d'apparition de 1 et 0

*/

	int cpt0 = 0; int cpt1 = 0;
	int result;

	for (int i = 0; i < iteration; i++){

		result = pileOuFace();

		if (result == 0)
			cpt0++;
		
		if (result == 1)
			cpt1++;
			
	}
	
	printf("Nombre d'iterations = %d \n", iteration);	
	printf("Nombre de 0 = %d/%d \n",cpt0, iteration);
	printf("Nombre de 1 = %d/%d \n",cpt1, iteration);

}

int dice(int nbFaces){
/*
	Fonction qui simule le jeu de dé avec un nbfaces nombre de faces
	Notons que les faces seront numérotees à partir de 0

*/
	int value;
	
	value = rand()%nbFaces;

	return value;
}


void diceStat(int nbFaces, int iteration){
/*
	Fonction qui compare le nombre d'apparitions de chaque face

*/
	int *tabFaces; //tableau qui stockera les occurrences de chaque face
	int result;

	tabFaces = calloc(nbFaces, sizeof(int));
	if(tabFaces == NULL){
		printf("Erreur d'allocation\n");
		return;

	}

	for(int i=0; i<iteration; i++){
		result = dice(nbFaces);
		*(tabFaces+result) += 1;
	}

	printf("Faces de 0 à %d\n", nbFaces-1);
	printf("Nombre d'iterations = %d \n\n", iteration);

	for(int i=0; i<nbFaces; i++)
		printf("Nombre de %d = %d/%d \n",i,tabFaces[i],iteration);

	printf("\n");
}

int intRand(){
/*
 	Fonction qui génère un pseudo-random number sous la forme 5*X+1
	Pour l'utiliser après comme la fonction rand(), on l'appelle comme suit:

	Exemple: variable = intRand()%n avec n étant la borne de votre choix
*/   

	int nbRand = 5*INTRAND_SEED+1;
	INTRAND_SEED = nbRand;


	return nbRand;
}


float floatRand(int modulo){
/*
	Fonction qui retourne les résultats de intRand divisés par modulo
*/
	float val;
	val = intRand() % modulo;
					
	
	if(val < 0)
		val = val + modulo;

	val = val/modulo;

	return val;
}