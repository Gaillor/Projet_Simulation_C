#ifndef FUNCTION_H
#define FUNCTION_H


int generate1(int seed, int iteration);
int pileOuFace();
void pileOuFaceStat(int iteration);
int dice(int nbFaces);
void diceStat(int nbFaces, int iteration);
int intRand();
int intRand2(int a, int c, int m, int seed);
float floatRand(int modulo);

#endif
