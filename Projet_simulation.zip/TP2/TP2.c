/* 
   A C-program for MT19937, with initialization improved 2002/1/26.
   Coded by Takuji Nishimura and Makoto Matsumoto.

   Before using, initialize the state by using init_genrand(seed)  
   or init_by_array(init_key, key_length).

   Copyright (C) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura,
   All rights reserved.                          

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

     1. Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.

     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.

     3. The names of its contributors may not be used to endorse or promote 
        products derived from this software without specific prior written 
        permission.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


   Any feedback is very welcome.
   http://www.math.sci.hiroshima-u.ac.jp/~m-mat/MT/emt.html
   email: m-mat @ math.sci.hiroshima-u.ac.jp (remove space)
*/

#include <stdio.h>

/* Period parameters */  
#define N 624
#define M 397
#define MATRIX_A 0x9908b0dfUL   /* constant vector a */
#define UPPER_MASK 0x80000000UL /* most significant w-r bits */
#define LOWER_MASK 0x7fffffffUL /* least significant r bits */

static unsigned long mt[N]; /* the array for the state vector  */
static int mti=N+1; /* mti==N+1 means mt[N] is not initialized */

/* initializes mt[N] with a seed */
void init_genrand(unsigned long s)
{
    mt[0]= s & 0xffffffffUL;
    for (mti=1; mti<N; mti++) {
        mt[mti] = 
	    (1812433253UL * (mt[mti-1] ^ (mt[mti-1] >> 30)) + mti); 
        /* See Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier. */
        /* In the previous versions, MSBs of the seed affect   */
        /* only MSBs of the array mt[].                        */
        /* 2002/01/09 modified by Makoto Matsumoto             */
        mt[mti] &= 0xffffffffUL;
        /* for >32 bit machines */
    }
}

/* initialize by an array with array-length */
/* init_key is the array for initializing keys */
/* key_length is its length */
/* slight change for C++, 2004/2/26 */
void init_by_array(unsigned long init_key[], int key_length)
{
    int i, j, k;
    init_genrand(19650218UL);
    i=1; j=0;
    k = (N>key_length ? N : key_length);
    for (; k; k--) {
        mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1664525UL))
          + init_key[j] + j; /* non linear */
        mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
        i++; j++;
        if (i>=N) { mt[0] = mt[N-1]; i=1; }
        if (j>=key_length) j=0;
    }
    for (k=N-1; k; k--) {
        mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1566083941UL))
          - i; /* non linear */
        mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
        i++;
        if (i>=N) { mt[0] = mt[N-1]; i=1; }
    }

    mt[0] = 0x80000000UL; /* MSB is 1; assuring non-zero initial array */ 
}

/* generates a random number on [0,0xffffffff]-interval */
unsigned long genrand_int32(void)
{
    unsigned long y;
    static unsigned long mag01[2]={0x0UL, MATRIX_A};
    /* mag01[x] = x * MATRIX_A  for x=0,1 */

    if (mti >= N) { /* generate N words at one time */
        int kk;

        if (mti == N+1)   /* if init_genrand() has not been called, */
            init_genrand(5489UL); /* a default initial seed is used */

        for (kk=0;kk<N-M;kk++) {
            y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
            mt[kk] = mt[kk+M] ^ (y >> 1) ^ mag01[y & 0x1UL];
        }
        for (;kk<N-1;kk++) {
            y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
            mt[kk] = mt[kk+(M-N)] ^ (y >> 1) ^ mag01[y & 0x1UL];
        }
        y = (mt[N-1]&UPPER_MASK)|(mt[0]&LOWER_MASK);
        mt[N-1] = mt[M-1] ^ (y >> 1) ^ mag01[y & 0x1UL];

        mti = 0;
    }
  
    y = mt[mti++];

    /* Tempering */
    y ^= (y >> 11);
    y ^= (y << 7) & 0x9d2c5680UL;
    y ^= (y << 15) & 0xefc60000UL;
    y ^= (y >> 18);

    return y;
}

/* generates a random number on [0,0x7fffffff]-interval */
long genrand_int31(void)
{
    return (long)(genrand_int32()>>1);
}

/* generates a random number on [0,1]-real-interval */
double genrand_real1(void)
{
    return genrand_int32()*(1.0/4294967295.0); 
    /* divided by 2^32-1 */ 
}

/* generates a random number on [0,1)-real-interval */
double genrand_real2(void)
{
    return genrand_int32()*(1.0/4294967296.0); 
    /* divided by 2^32 */
}

/* generates a random number on (0,1)-real-interval */
double genrand_real3(void)
{
    return (((double)genrand_int32()) + 0.5)*(1.0/4294967296.0); 
    /* divided by 2^32 */
}

/* generates a random number on [0,1) with 53-bit resolution*/
double genrand_res53(void) 
{ 
    unsigned long a=genrand_int32()>>5, b=genrand_int32()>>6; 
    return(a*67108864.0+b)*(1.0/9007199254740992.0); 
} 
/* These real versions are due to Isaku Wada, 2002/01/09 added */


/**************************************************************/
/**************************************************************/
/**************************************************************/

double uniformRandom(double a, double b);
void affichePourcentageClasse(int iteration);
void afficheProbaHdl(int iteration);
double negExp(double mean);
void negExpTest(double mean, int iteration);
int *biasedDice(int iteration, double Moy);
void biasedDiceTest(int iteration, double Moy);
int *getTabDiceExperiment(int iteration);
int getNumberDice();
void getInfoDiceExperiment(int *tab, int taille, int iteration);
double *boxAndMuller(double mu, double sigma);
int *getInTabBoxAndMuller(int mu, int sigma, int taille, int iteration);
void getFileInCsv(int *tab, int taille, int pas);

/**************************************************************/
/********************* FONCTION PRINCIPALE ********************/
/**************************************************************/


int main(void)
{
    unsigned long init[4]={0x123, 0x234, 0x345, 0x456}, length=4;
    init_by_array(init, length);
//   printf("%.1f\n", uniformRandom(-98,57.7));
//    for(int i=0; i<20; i++)
//        printf("%.1f ", uniformRandom(-98,57.7));
//    affichePourcentageClasse(1000000);
  
//    afficheProbaHdl(1000000);

//    negExpTest(10,1000);
//    biasedDiceTest(1000000,10);
//    int *tab = getTabDiceExperiment(100000);
//    getInfoDiceExperiment(tab,201,10000);

//    int *tab = getInTabBoxAndMuller(0,1,20,100000);

//    getFileInCsv(tab,200,40);

    return 0;
}


/*------------------------------------------------------------*/
/*-----------------PARTIE EXERCICE 2--------------------------*/
/*------------------------------------------------------------*/

double uniformRandom(double a, double b){
/*  Cette fonction retourne une valeur réelle aléatoire entre a et b
    en utilisant la fonction genrand_real1() de Makoto --> qui retourne un réel entre [0,1].
    Mathématiquement la valeur retournée sera comprise entre [a,b]
*/

    double value;
    value = a+(b-a)*genrand_real1();
    
    return value;
}


/*------------------------------------------------------------*/
/*-----------------PARTIE EXERCICE 3--------------------------*/
/*------------------------------------------------------------*/

void affichePourcentageClasse(int iteration){
/*
    Nous avons trois classes de tirage de nombre(entre[0,1]) réparties selon les pourcentages suivant:
    A(35%), B(45%), C(20%).
    Cette fonction réalise des tirages selon le nombre d'itération pris en paramètre
    Elle affichera à la fin le nombre total de tirages et les classifie dans la classe appropriée
*/

    double tirage;                                  //recupère le réel entre 0 et 1
    int *tabClass = malloc(3*sizeof(int));          //tableau qui stockera le nombre de tirage de chaque classe

    if (tabClass == NULL){
        printf("Erreur d'allocation de mémoire\n");
        return;
    }

    tabClass[0] = 0;
    tabClass[1] = 0;
    tabClass[2] = 0;

    for(int i=0; i<iteration; i++){
        tirage = genrand_real1();

/*    if(tirage <= 0.20)
            tabClass[2] += 1;
        if (tirage > 0.20 && tirage <= 0.35)
            tabClass[0] += 1;
        if(tirage > 0.35 && tirage <= 0.45 )
            tabClass[1] += 1;
*/
        if(tirage <= 0.20)
            tabClass[2] += 1;
        if (tirage <= 0.35)
            tabClass[0] += 1;
        if(tirage <= 0.45 )
            tabClass[1] += 1;

    }

    int pA,pB,pC;
    pA = ((double)tabClass[0]/iteration)*100;
    pB = ((double)tabClass[1]/iteration)*100;
    pC = ((double)tabClass[2]/iteration)*100;

    printf("Nombre d'itérations: %d\n", iteration);
    printf("Classe A: %d%%\nClasse B: %d%%\nClasse C: %d%%\n",pA,pB,pC);

    free(tabClass);
}

void afficheProbaHdl(int totalPopulation){
/*
    Cette fonction affiche la probabilité d'apparition de chaque classe d'individu
    Nous avons 6 classes de "cholesterol" réparties entre [40,70]
    Les classes sont: A[40-45],B[45;50],C[50;55],D[55;60];C[60;65];D[65;70] 
*/
    double *class = malloc(6*sizeof(double));     //tableau de classes
    if(class == NULL){
        printf("Erreur d'allocation dans <affichePClasseHdl>\n");
        return;
    }

    for(int i=0; i<6; i++)
        class[i] = 0;
    
    double cholesterol;
    for(int i=0; i<totalPopulation; i++){
        cholesterol = uniformRandom(40,70);     //génération de nombre réel entre 40 et 70

        if(cholesterol >= 40 && cholesterol < 45)
            class[0] += 1;
        else if(cholesterol >= 45 && cholesterol < 50 )
            class[1] += 1;
        else if(cholesterol >= 50 && cholesterol < 55)
            class[2] += 1;
        else if(cholesterol >= 55 && cholesterol < 60 )
            class[3] += 1;
        else if(cholesterol >=60 && cholesterol < 65)
            class[4] += 1;
        else if(cholesterol >= 65 && cholesterol <= 70 )
            class[5] += 1;
    }

    for(int i=0; i<6; i++)
        class[i] = class[i]/totalPopulation;

    printf("\n---------- Probabilités -----------\n");

    printf("Classe A: %f\n", class[0]);
    printf("Classe B: %f\n", class[1]);
    printf("Classe C: %f\n", class[2]);
    printf("Classe D: %f\n", class[3]);
    printf("Classe E: %f\n", class[4]);
    printf("Classe F: %f\n", class[5]);

    printf("\n------ Probabilités cumulées ------\n");

    double probaCumul[6] = {0,0,0,0,0,0};
    probaCumul[0] = class[0];

    for(int i=1; i<6; i++)
        probaCumul[i] = probaCumul[i-1] + class[i];

    for(int i=0 ; i<6; i++)
        printf("Proba[%d] --> %f\n", i+1, probaCumul[i]);


    free(class);
}


/*------------------------------------------------------------*/
/*-----------------PARTIE EXERCICE 4--------------------------*/
/*------------------------------------------------------------*/

double negExp(double mean){
/*
    Cette fonction réalise la loi exponentielle négative
    Elle retourne un réel x = -mean*ln(1-RND)
    mean étant une moyenne demandée en paramètre et RND un réel
    obtenu entre 0 et 1
*/

    double x,RND;
    RND = genrand_real1();

    x = (-1)*mean*log10(1-RND);

    return x;
}

void negExpTest(double mean, int iteration){
    for(int i=0; i<iteration; i++){
        if(i % 15 == 0)
            printf("\n");

        printf("%.2f ", negExp(mean));
    }

}

int *biasedDice(int iteration, double Moy){
/*
    Cette fonction retourne un tableau de 21 cases
    Qui contient les fréquences d''apparition des nombres
    entre [0,1],[1,2], ... [20,..]
    La dernière case contiendra les nombres supérieurs à 20
*/
    int *tab = malloc(21*sizeof(int));
    for(int i=0; i<21; i++)
        tab[i] = 0;                   //initialisation des compteurs à 0

    double number;
    for(int i=0; i<iteration; i++){
        number = negExp(Moy);          //M étant la moyenne théorique

        if(number < 20)
            tab[(int)number] ++;
        else
            tab[20] ++;            
    }
    
    return tab;
}

void biasedDiceTest(int iteration, double Moy){
    int *tab;
    tab = biasedDice(iteration,Moy);

    int j;
    for(int i=0; i<20; i++){
        printf("[%d - %d] --> %d apparitions\n",i,i+1,tab[i]);
        j = i;
    }

    printf("[%d - ..] --> %d apparitions\n",j+1,tab[j]);

    int total=0;
    for(int i=0; i<21; i++)
        total+= tab[i];
    
    printf("\nTotal = %d de simulations\n\n", total);
}

/*------------------------------------------------------------*/
/*-----------------PARTIE EXERCICE 5--------------------------*/
/*------------------------------------------------------------*/

int getNumberDice(){
/*
    Cette fonction retourne la somme des nombres 
    Obtenus pour 40 lancés de dés
*/
    int somme = 0;
    int number = 0;

    for(int i=0; i<40; i++){
        number = (genrand_int31()%6)+1;
        somme += number;
    }

    return somme;
}


int *getTabDiceExperiment(int iteration){
/*
    Cette fonction retourne un tableau de 240 valeurs
    Les valeurs sont comprises entre 40-240
    Chaque case contiendra le nombre d'apparition des nombres
    40,41,.....,240
    Chaque valeur sera la somme de nombres obtenus sur des lancés de dés
    nombre compris entre (1-6) avec 40 lancés/expérience
*/
    int *tab = malloc(201*sizeof(int));     //Je garde la derniere case pour le total de nombre généré
    if(tab == NULL){
        printf("Erreur d'allocation dans getTabDiceExperiment\n");
        return NULL;
    }

    for(int i=0; i<200; i++)
        tab[i] = 0;         //initialisation des compteurs à 0

    int compteur = 0;
    int total = 0;
    for(int i=0; i<iteration; i++){
        compteur = getNumberDice();
        total += compteur;

        if(compteur == 240)
            tab[compteur-41]++;
        else
            tab[compteur-40]++;
    }

    tab[200] = total;

    return tab;
}

void getInfoDiceExperiment(int *tab, int taille, int iteration){
/*
    Cette fonction affiche les informations sur l'expérience
    du lancé de dé

*/
    int total = tab[200];
    int minimum, maximum, indiceMin, indiceMax;
    int moyenne;

    indiceMax = 0;
    indiceMin = 0;

    minimum = tab[0];
    maximum = tab[0]; 

    for(int i=0; i<taille-1; i++){
        
        if(tab[i] < minimum){
            minimum = tab[i];
            indiceMin = i;
        }

        if(tab[i] > maximum){
            maximum = tab[i];
            indiceMax = i;
        }
    
    }
    moyenne = total/iteration;

    printf("Moyenne des nombres apparus = %d\n", moyenne);
    printf("Maximum = %d fois, nombre = %d\n", maximum, indiceMax+40);
    printf("Minimum = %d fois, nombre = %d\n\n", minimum, indiceMin+40);
}


double *boxAndMuller(double mu, double sigma){
/*
    Cette fonction génère des nombres X1 et X2 suivant la formule
    de Box et Muller, ces nombres seront stockés dans un tableau de
    2 cases qu'on retournera à la fin.
    mu: la moyenne autour de laquelle  les nombres tournent autour
    sigma: la déviation 
*/
    double *tab = malloc(2*sizeof(double));
    double x1, x2;
    double rN1 = genrand_real1();
    double rN2 = genrand_real1();

    x1 = cos(2*M_PI*rN2);
    x1 = x1*sqrt(-2*log10(rN1))*sigma;
    x1 = x1 + mu;

    x2 = sin(2*M_PI*rN2);
    x2 = x2*sqrt(-2*log10(rN1))*sigma;
    x2 = x2 + mu;

    if(x1 < x2){
        tab[0] = x1;
        tab[1] = x2;
    }
    else{
        tab[0] = x2;
        tab[1] = x1;
    }

    return tab;
}


int *getInTabBoxAndMuller(int mu, int sigma, int taille, int iteration){
/*
    Cette fonction retourne un tableau de nombres apparus
    suivant la formule de Box et Muller. Dans cette fonction
    nous stockerons uniquement les nombres compris entre [-5,5]
    et on retournera un tableau de 20 cases
*/

    int *tab = malloc(20*sizeof(int));
    
    for(int i=0; i<taille; i++)
        tab[i] = 0;             //initialisation des compteurs à 0

    double pasDeCase = (2*5.0)/taille;
    double *tabX1X2 = malloc(2*sizeof(double));
    int iX1, iX2;

    for(int i=0; i<iteration; i++){
        tabX1X2 = boxAndMuller(mu,sigma);
        iX1 = (int)(((tabX1X2[0])+5)/pasDeCase);
        iX2 = (int)(((tabX1X2[1])+5)/pasDeCase);

        if((iX1 >= 0) && (iX1 < taille))
            tab[iX1] += 1;
        if((iX2 >= 0) && (iX2 < taille))
            tab[iX2] += 1;
    }

    return tab;
}


void getFileInCsv(int *tab, int taille, int pas){
/*
    Cette fonction récupère les données stockées dans un tableau
    dans un fichier tableur en .xls
    Pour faciliter les manipulations de données sous-forme de graphes

*/
    FILE *p = fopen("resultat.csv","w");

    if(p != NULL){
        for(int i=0; i<taille; i++){
            if(i == taille-1)
                fprintf(p,"%d", i+pas);
            else
                fprintf(p,"%d;\n", i+pas);      //pour les abscisses
        }
        
        fprintf(p,"\n");

        for(int i=0; i<taille; i++){
            if(i == taille-1)
                fprintf(p,"%d",tab[i]);
            else
                fprintf(p,"%d;\n",tab[i]);
        }
    }
}